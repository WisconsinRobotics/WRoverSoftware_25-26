#define PIN_STA PD_2
#define PIN_IDE A11
#define PIN_VSI A9

#define PIN_RGB_R PF_1
#define PIN_RGB_G PF_3
#define PIN_RGB_B PF_2

#define VIDE_MPG401 1.516
#define VIDE_DISCONN 3.3
#define EPS_VIDE 0.2

#define UN_VDIV_VSI ((double)3.55)
#define UN_VDIV_VSI_CORR ((double)0.9645)

#define BITS_ADC 12
#define BMAX_ADC (1 << BITS_ADC)
#define AVOLTS 3.3

#define DEFAULT_I2C 0

#include <SPI.h>
#include <Wire.h>
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1306.h"

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 32 // OLED display height, in pixels

// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
// The pins for I2C are defined by the Wire-library. 
// On an arduino UNO:       A4(SDA), A5(SCL)
// On an arduino MEGA 2560: 20(SDA), 21(SCL)
// On an arduino LEONARDO:   2(SDA),  3(SCL), ...
#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire0, OLED_RESET);

void initOled() {
  // Wait for display
  delay(500);

  // SSD1306_SWITCHCAPVCC = generate display voltage from 3.3V internally
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Don't proceed, loop forever
  }

  // Show initial display buffer contents on the screen --
  // the library initializes this with an Adafruit splash screen.
  display.display();
  delay(2000); // Pause for 2 seconds

  // Clear the buffer
  display.clearDisplay();
}

// ACTUAL GAUGECTRL CODE

void setup() {
  // put your setup code here, to run once:
  pinMode(PIN_STA, INPUT);
  pinMode(PIN_RGB_R, OUTPUT);
  pinMode(PIN_RGB_G, OUTPUT);
  pinMode(PIN_RGB_B, OUTPUT);
  initOled();
}


double analogReadV(int pin) {
  return (((double)analogRead(pin)) / BMAX_ADC) * AVOLTS;
}

enum SenType { TYPE_UNKNOWNSEN, TYPE_MPG401 };

enum SenErr {
  SEN_OK,
  SEN_ERR_NOSUP,
  SEN_ERR_PIRANIFAIL,
  SEN_ERR_OVERRANGE,
  SEN_ERR_UNDERRANGE,
  SEN_ERR_UNKNOWNSEN
};

struct SenData {
  enum SenErr err;
  bool cc_mode;
  enum SenType type;
  double p;
};

double convertPressure(double vvsi) {
  double p_exp = (vvsi - 8.6) / 0.6;
  double p = pow(10, p_exp) * 750;
  return p;
}

void readSensor(struct SenData* sen) {
  sen->type = TYPE_UNKNOWNSEN;
  sen->p = 0;
  sen->err = SEN_OK;
  sen->cc_mode = digitalRead(PIN_STA) == HIGH;
  double vide = analogReadV(PIN_IDE);
  if (abs(vide - VIDE_MPG401) < EPS_VIDE) sen->type = TYPE_MPG401;
  if (sen->type == TYPE_UNKNOWNSEN) { sen->err = SEN_ERR_UNKNOWNSEN; return; }
  double vvsi = analogReadV(PIN_VSI) * UN_VDIV_VSI * UN_VDIV_VSI_CORR;
  if (vvsi < 0.7) {
    sen->err = SEN_ERR_NOSUP;
  } else if (vvsi > 9.3) {
    sen->err = SEN_ERR_PIRANIFAIL;
  } else if (vvsi > 8.9) {
    sen->err = SEN_ERR_OVERRANGE;
  } else if (vvsi < 1.82) {
    sen->err = SEN_ERR_UNDERRANGE;
  } else {
    sen->p = convertPressure(vvsi);
  }
}

struct SenData sens;

void loop() {
  readSensor(&sens);
  updateDisplay();
  if (!sens.err) {
    digitalWrite(PIN_RGB_R, LOW);
    if (abs(sens.p - 760) < 76) {
      digitalWrite(PIN_RGB_G, HIGH);
      digitalWrite(PIN_RGB_B, LOW);
    } else {
      digitalWrite(PIN_RGB_G, LOW);
      digitalWrite(PIN_RGB_B, HIGH);  
    }
  } else {
    digitalWrite(PIN_RGB_R, HIGH);
    digitalWrite(PIN_RGB_G, LOW);
    digitalWrite(PIN_RGB_B, LOW);
  }
  delay(500);
}

void updateDisplay() {
  if (!sens.err) {
    display.clearDisplay();
    display.setTextSize(3);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(10, 0);
    display.cp437(true);
    double p = sens.p;
    int expon = floor(log10(p));
    double facto = p * pow(10, -expon);
    display.print(facto);
    //display.print("e");
    display.setCursor(110, 0);
    display.println(abs(expon));
    display.setCursor(82, 0);
    display.setTextSize(2);
    display.print("e");
    display.print((expon >= 0) ? "+" : "-");
    display.setCursor(10, 25);
    display.setTextSize(1);
    display.print("torr     ");
    display.print(sens.cc_mode ? "Pirani" : "Pirani+CC");
    display.display();
  } else {
    display.clearDisplay();
    display.setTextSize(4);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(10, 0);
    display.cp437(true);
    switch (sens.err) {
      case SEN_ERR_NOSUP:
        display.print("\x13SUP");
        break;
      case SEN_ERR_PIRANIFAIL:
        display.print("\x13PIR");
        break;
      case SEN_ERR_OVERRANGE:
        display.print("\x13OVR");
        break;
     case SEN_ERR_UNDERRANGE:
        display.print("\x13UND");
        break;
     case SEN_ERR_UNKNOWNSEN:
        display.print("\x13SEN");
        break;
      default:
        display.print("\x13???");
    }
    display.display();
  }
}
